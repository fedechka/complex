<?php

use PHPUnit\Framework\TestCase;

class complexTest extends TestCase
{
    public function testCreateFromTrig()
    {
        $this->assertEquals(complex::createFromTrig(3, pi()/3)->toText(), '1.5+2.5980762113533i<br />');
    }

    public function testAdd()
    {
        $z1 = new complex(2, 3);
        $this->assertEquals($z1->add(new complex(4, 5))->toText(), '6+8i<br />');
    }

    public function testSub()
    {
        $z1 = new complex(2, 3);
        $this->assertEquals($z1->sub(new complex(6, 7))->toText(), '-4-4i<br />');
    }

    public function testMultiply()
    {
        $z1 = new complex(2, 3);
        $this->assertEquals($z1->multiply(new complex(8, 9))->toText(), '-11+42i<br />');
    }

    public function testDivide()
    {
        $z1 = new complex(2, 3);
        $this->assertEquals($z1->divide(new complex(1, 2))->toText(), '1.6-0.2i<br />');
        try {
            $z1->divide(new complex(0, 0))->toText();
        } catch (Exception $exception){
            $this->assertEquals($exception->getMessage(), 'Cannot divide by zero');
        }
    }
}
