<?php

/**
 * Класс для работы с комплексными числами
 */
class complex
{
    public $re, $im;

    /**
     * @param float $re
     * @param float $im
     */
    public function __construct(float $re, float $im)
    {
        $this->re = $re;
        $this->im = $im;
    }

    /**
     * Создание из тригонометрической формы
     * @param float $mod
     * @param float $arg
     * @return complex
     */
    public static function createFromTrig(float $mod, float $arg) : complex
    {
        return new self($mod * cos($arg), $mod * sin($arg));
    }

    /**
     * Сложение
     * @param complex $z2
     * @return complex
     */
    public function add(complex $z2) : complex
    {
        $re = $this->re + $z2->re;
        $im = $this->im + $z2->im;
        return new self($re, $im);
    }

    /**
     * Вычитание
     * @param complex $z2
     * @return complex
     */
    public function sub(complex $z2) : complex
    {
        $re = $this->re - $z2->re;
        $im = $this->im - $z2->im;
        return new self($re, $im);
    }

    /**
     * Умножение
     * @param complex $z2
     * @return complex
     */
    public function multiply(complex $z2) : complex
    {
        $re = $this->re * $z2->re - $this->im * $z2->im;
        $im = $this->re * $z2->im + $this->im * $z2->re;
        return new self($re, $im);
    }

    /**
     * Деление
     * @param complex $z2
     * @return complex
     * @throws Exception
     */
    public function divide(complex $z2) : complex
    {
        if(!$z2->re && !$z2->im) {
            throw new Exception('Cannot divide by zero');
        }
        $re = ($this->re * $z2->re + $this->im * $z2->im) / ($z2->re * $z2->re + $z2->im * $z2->im);
        $im = ($this->im * $z2->re - $this->re * $z2->im) / ($z2->re * $z2->re + $z2->im * $z2->im);
        return new self($re, $im);
    }

    /**
     * Вывод в человекочитаемый формат
     * @return string
     */
    public function toText() : string
    {
        $ret = '';
        if($this->re) {
            $ret .= $this->re;
        }
        if($this->im) {
            $ret .= ($this->im > 0 ? '+' : '').$this->im.'i';
        }
        return $ret."<br />";
    }


}

/*
echo complex::createFromTrig(3, pi()/3)->toText();
$z1 = new complex(2, 3);
try {
    echo $z1->add(new complex(4, 5))->toText();
    echo $z1->sub(new complex(6, 7))->toText();
    echo $z1->multiply(new complex(8, 9))->toText();
    echo $z1->divide(new complex(1, 2))->toText();
    echo $z1->divide(new complex(0, 0))->toText();
} catch (Exception $exception){
    echo $exception->getMessage()."<br />";
}*/